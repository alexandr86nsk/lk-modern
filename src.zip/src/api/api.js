import * as auth from './auth/auth';
import * as briefcase from './briefcase/briefcase';
import * as settings from './settings/settings';

const api = {
  ...auth,
  ...briefcase,
  ...settings,
};

export default api;
