import axios from 'axios';
import qs from '../qs';

export const getMainSettings = () => axios.get(`${qs}Settings/Get`);

export const getRecallSettings = () => axios.get(`${qs}RetryRules/Get`);

export const updateMainSettings = (item) => axios.post(`${qs}Settings/Update`, item);

export const updateRecallSettings = (item) => axios.post(`${qs}RetryRules/Update`, item);
