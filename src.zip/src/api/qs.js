// const qs = 'http://web-nsk:5089/api/';
// const qs = 'http://web-nsk:9555/api/';
const qs = `${window.location.origin}/api/`;

export default qs;
