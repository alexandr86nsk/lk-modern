import axios from 'axios';
import qs from '../qs';


export const getBriefCaseList = () => axios.get(`${qs}Briefcase/GetList`);

export const getBriefCase = (id) => axios.get(`${qs}Briefcase/Get/?itemId=${id}`);

export const addBriefCase = (title) => axios.post(`${qs}Briefcase/Add/?title=${title}`);

export const updateBriefCase = (item) => axios.post(`${qs}Briefcase/Update`, item);

export const deleteBriefCase = (id) => axios.post(`${qs}Briefcase/Delete/?itemId=${id}`);

export const startBriefCase = (id) => axios.get(`${qs}Briefcase/Start/?itemId=${id}`);

export const stopBriefCase = (id) => axios.get(`${qs}Briefcase/StopExternal/?itemId=${id}`);

export const uploadBriefCaseFile = (id, files) => {
  const data = new FormData();
  data.append('itemId', id);
  for (let i = 0; i < files.length; i += 1) {
    data.append('FILES[]', files[i]);
  }
  return axios.post(`${qs}Briefcase/UploadFile`, data);
};

export const getBriefCaseItemCalls = (id) => axios.get(`${qs}BriefcaseItems/GetList/?briefcaseId=${id}`);

export const getBriefCaseItem = (id) => axios.get(`${qs}Briefcase/Get/?itemId=${id}`);

export const addBriefCaseItem = (item) => axios.get(`${qs}BriefcaseItems/Add/?title=${item}`);

export const updateBriefCaseItem = (item) => axios.post(`${qs}BriefcaseItems/Update`, item);

export const deleteBriefCaseItem = (id) => axios.delete(`${qs}BriefcaseItems/Delete/${id}`);
