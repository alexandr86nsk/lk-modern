import BriefCasePage from '../containers/BriefcasePage/BriefcaseListPage';
import BriefCasePageItem from '../containers/BriefcasePage/BriefcaseItemPage';
import SettingsPage from '../containers/SettingsPage/SettingsPage';
import AuthPage from '../containers/AuthPage/AuthPage';

const routes = [
  {
    path: '/briefcase',
    exact: true,
    component: BriefCasePage,
  },
  {
    path: '/briefcase/:index',
    exact: true,
    component: BriefCasePageItem,
  },
  {
    path: '/settings',
    exact: true,
    component: SettingsPage,
  },
  {
    path: '/auth',
    exact: true,
    component: AuthPage,
  },
];

export default routes;
