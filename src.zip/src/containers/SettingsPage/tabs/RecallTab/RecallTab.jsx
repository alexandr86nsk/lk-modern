import React from 'react';
import '../../SettingsPage.scss';
import { connect } from 'react-redux';
import actions from '../../../../redux/actions/actions';
import UIButton from '../../../../components/UIButton/UIButton';
import RecallItem from './RecallItem';

function RecallTab(props) {
  const {
    recall,
    updatingRecallSettings,
    settingsStoreUpdateRecall,
    settingsStoreChangeRecallItem,
  } = props;

  const handleChangeValue = React.useCallback((id, editName, editValue) => {
    settingsStoreChangeRecallItem(id, {
      [editName]: editValue,
    });
  }, [settingsStoreChangeRecallItem]);

  const handleSaveChanges = React.useCallback(() => {
    settingsStoreUpdateRecall(recall);
  }, [recall, settingsStoreUpdateRecall]);

  return (
    <div className="settings-page__recall-tab">
      <div className="settings-page__input-block">
        {
          recall.map((v) => (
            <RecallItem key={v.EventCode} data={v} callback={handleChangeValue} />
          ))
        }
      </div>
      <div className="controls">
        <UIButton
          title="Сохранить настройки перезвона"
          type="positive"
          maxContent
          callback={handleSaveChanges}
          loading={updatingRecallSettings}
        />
      </div>
    </div>
  );
}

const mapStateToProps = (state) => ({
  recall: state.settingsStore.recall,
  updatingRecallSettings: state.settingsStore.updatingRecallSettings,
});

const mapDispatchToProps = { ...actions };

export default connect(mapStateToProps, mapDispatchToProps)(RecallTab);
