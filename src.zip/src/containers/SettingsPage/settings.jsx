import React from 'react';
import MainTab from './tabs/MainTab/MainTab';
import RecallTab from './tabs/RecallTab/RecallTab';

const settingsTabs = [
  {
    id: 0,
    title: 'Основные',
    item: <MainTab />,
  },
  {
    id: 1,
    title: 'Настройки перезвона',
    item: <RecallTab />,
  },
];

export default settingsTabs;
