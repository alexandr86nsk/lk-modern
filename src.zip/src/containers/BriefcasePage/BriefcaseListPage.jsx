import React from 'react';
import './BriefcasePage.scss';
import { connect } from 'react-redux';
import actions from '../../redux/actions/actions';
import UITable from '../../components/UITable/UITable';
import { listHeader } from './settings';
import history from '../../history/history';
import UIBlockTitle from '../../components/UIBlockTitle/UIBlockTitle';
import WarningIcon from '../../static/images/warning-24px.svg';
import BriefcaseAddItem from './common/BriefcaseAddItem';


function BriefcaseListPage(props) {
  const {
    dataLoaded,
    list,
    briefcaseStoreGetBriefcaseList,
    briefcaseStoreStartBriefcase,
    briefcaseStoreStopBriefcase,
    briefcaseStoreAddBriefcase,
    briefcaseStoreUpdateBriefcase,
    briefcaseStoreUpdateBriefcaseFile,
    briefcaseStoreDeleteBriefcase,
    modalStoreSetSection,
    pageControlStoreSet,
    briefcaseStoreGetBriefcaseListCancel,
    briefcaseStoreStartBriefcaseCancel,
    briefcaseStoreStopBriefcaseCancel,
    briefcaseStoreUpdateBriefcaseCancel,
    briefcaseStoreUpdateBriefcaseFileCancel,
    briefcaseStoreAddBriefcaseCancel,
    pageControlStoreClear,
    briefcaseListStoreClear,
  } = props;

  React.useEffect(() => {
    briefcaseStoreGetBriefcaseList();
  }, [briefcaseStoreGetBriefcaseList]);

  const handleRefreshTable = React.useCallback(() => {
    briefcaseStoreGetBriefcaseList();
  }, [briefcaseStoreGetBriefcaseList]);

  const handleEdit = React.useCallback((el) => {
    history.push(`/briefcase/${el.BriefcaseId}`);
  }, []);

  const handleStart = React.useCallback((el) => {
    briefcaseStoreStartBriefcase(el.BriefcaseId);
  }, [briefcaseStoreStartBriefcase]);

  const handleStop = React.useCallback((el) => {
    briefcaseStoreStopBriefcase(el.BriefcaseId);
  }, [briefcaseStoreStopBriefcase]);

  const handleUpdate = React.useCallback((item) => {
    briefcaseStoreUpdateBriefcase(item);
  }, [briefcaseStoreUpdateBriefcase]);

  const handleUpload = React.useCallback((el, files) => {
    briefcaseStoreUpdateBriefcaseFile(el.BriefcaseId, files);
  }, [briefcaseStoreUpdateBriefcaseFile]);

  const removeBriefcase = React.useCallback((value) => {
    briefcaseStoreDeleteBriefcase(value.BriefcaseId);
  }, [briefcaseStoreDeleteBriefcase]);

  const handleRemoveBriefcase = React.useCallback((value) => {
    modalStoreSetSection({
      show: true,
      outputBody: {
        icon: <WarningIcon />,
        title: 'Важно',
        body: <div>{`Действительно хотите удалить "${value.Title}"?`}</div>,
      },
      data: value,
      callback: removeBriefcase,
    });
  }, [modalStoreSetSection, removeBriefcase]);

  const handleHideAddModal = React.useCallback((el, value) => {
    briefcaseStoreAddBriefcase(value.name);
  }, [briefcaseStoreAddBriefcase]);

  const handleAdd = React.useCallback(() => {
    modalStoreSetSection({
      show: true,
      tempData: {
        name: '',
      },
      outputBody: {
        title: 'Добавление кампании',
        body: <BriefcaseAddItem />,
        buttons: {
          positive: 'Создать',
          negative: 'Отмена',
        },
      },
      requiredFields: [
        {
          name: 'name',
          type: 'length',
          validation: '1',
        },
      ],
      callback: handleHideAddModal,
    });
  }, [handleHideAddModal, modalStoreSetSection]);

  React.useEffect(() => {
    setTimeout(() => {
      pageControlStoreSet({
        show: true,
        data: {
          actions: {
            add: handleAdd,
          },
          loading: {
            add: false,
          },
        },
      });
    }, 200);
  }, [handleAdd, pageControlStoreSet]);

  React.useEffect(() => () => {
    briefcaseStoreGetBriefcaseListCancel();
    briefcaseStoreStartBriefcaseCancel();
    briefcaseStoreStopBriefcaseCancel();
    briefcaseStoreUpdateBriefcaseCancel();
    briefcaseStoreUpdateBriefcaseFileCancel();
    briefcaseStoreAddBriefcaseCancel();
    pageControlStoreClear();
    briefcaseListStoreClear();
  }, [
    briefcaseStoreGetBriefcaseListCancel,
    briefcaseStoreStartBriefcaseCancel,
    briefcaseStoreStopBriefcaseCancel,
    briefcaseStoreUpdateBriefcaseCancel,
    briefcaseStoreUpdateBriefcaseFileCancel,
    briefcaseStoreAddBriefcaseCancel,
    pageControlStoreClear,
    briefcaseListStoreClear,
  ]);

  return (
    <div className="briefcase-list page__content">
      <UIBlockTitle title="Кампании" />
      <UITable
        header={listHeader}
        data={list}
        customId="BriefcaseId"
        pagination
        refresh
        refreshCallback={handleRefreshTable}
        search
        actions={{
          edit: handleEdit,
          start: handleStart,
          stop: handleStop,
          remove: handleRemoveBriefcase,
          upload: handleUpload,
          cellClick: handleEdit,
        }}
        empty="Список кампаний пуст"
        loadingData={!dataLoaded}
        selectable
      />
    </div>
  );
}

const mapStateToProps = (state) => ({
  dataLoaded: state.briefcaseListStore.dataLoaded,
  list: state.briefcaseListStore.list,
});

const mapDispatchToProps = { ...actions };

export default connect(mapStateToProps, mapDispatchToProps)(BriefcaseListPage);
