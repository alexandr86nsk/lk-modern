import React from 'react';
import { connect } from 'react-redux';
import actions from '../../../redux/actions/actions';
import UIInput from '../../../components/UIInput/UIInput';

function BriefcaseAddItem(props) {
  const {
    tempData,
    modalStoreSetTempDataValue,
  } = props;

  return (
    <>
      <UIInput
        title="Название кампании:"
        name="name"
        data={tempData.name}
        callback={modalStoreSetTempDataValue}
      />
    </>
  );
}

const mapStateToProps = (state) => ({
  tempData: state.modalStore.tempData,
});

const mapDispatchToProps = { ...actions };

export default connect(mapStateToProps, mapDispatchToProps)(BriefcaseAddItem);
