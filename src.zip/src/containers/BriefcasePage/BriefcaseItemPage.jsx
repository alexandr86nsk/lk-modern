import React from 'react';
import { connect } from 'react-redux';
import actions from '../../redux/actions/actions';
import { itemHeader } from './settings';
import UITable from '../../components/UITable/UITable';
import history from '../../history/history';
import UIBlockTitle from '../../components/UIBlockTitle/UIBlockTitle';
import UILoader from '../../components/UILoader/UILoader';


function BriefcaseItemPage(props) {
  const {
    id,
    dataLoaded,
    tableDataLoaded,
    title,
    items,
    path,
    briefcaseStoreGetBriefcase,
    briefcaseStoreGetBriefcaseCancel,
    briefcaseItemStoreClear,
    pageControlStoreSet,
    pageControlStoreClear,
  } = props;

  React.useEffect(() => {
    const itemId = path.split('/')[2] || '';
    if (itemId) {
      briefcaseStoreGetBriefcase(itemId);
    }
  }, [briefcaseStoreGetBriefcase, path]);

  const handleBackClick = React.useCallback(() => {
    history.push('/briefcase');
  }, []);

  React.useEffect(() => {
    setTimeout(() => {
      pageControlStoreSet({
        show: true,
        data: {
          actions: {
            back: handleBackClick,
          },
        },
      });
    }, 200);
  }, [handleBackClick, pageControlStoreSet]);

  const handleRefreshTable = React.useCallback(() => {
    if (id) {
      briefcaseStoreGetBriefcase(id);
    }
  }, [id, briefcaseStoreGetBriefcase]);

  React.useEffect(() => () => {
    briefcaseStoreGetBriefcaseCancel();
    briefcaseItemStoreClear();
    pageControlStoreClear();
  }, [
    briefcaseStoreGetBriefcaseCancel,
    briefcaseItemStoreClear,
    pageControlStoreClear,
  ]);

  return (
    <div className="briefcase-item page__content">
      {!dataLoaded ? <UILoader text="Загрузка" size="large" /> : (
        <>
          <UIBlockTitle title={title} />
          <UITable
            header={itemHeader}
            customId="BriefcaseItemId"
            data={items}
            empty="Список пуст"
            loadingData={!tableDataLoaded}
            pagination
            refresh
            refreshCallback={handleRefreshTable}
            search
            selectable
          />
        </>
      )}
    </div>
  );
}

const mapStateToProps = (state) => ({
  dataLoaded: state.briefcaseItemStore.dataLoaded,
  id: state.briefcaseItemStore.BriefcaseId,
  tableDataLoaded: state.briefcaseItemStore.tableDataLoaded,
  items: state.briefcaseItemStore.items,
  title: state.briefcaseItemStore.Title,
  path: state.router.location.pathname,
});

const mapDispatchToProps = { ...actions };

export default connect(mapStateToProps, mapDispatchToProps)(BriefcaseItemPage);
