import React from 'react';
import './PageFooter.scss';


function PageFooter() {
  return (
    <header className="page-footer" />
  );
}

export default PageFooter;
