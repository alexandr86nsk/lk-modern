import { takeLatest } from 'redux-saga/effects';
import { fetchWinAuth, fetchLogIn } from './auth/authSaga';
import * as briefcaseSaga from './briefcase/briefcaseSaga';
import * as settingsSaga from './settings/settingsSaga';


function* rootSaga() {
  yield takeLatest('AUTH_STORE_WIN_AUTH', fetchWinAuth);
  yield takeLatest('AUTH_STORE_LOG_IN', fetchLogIn);
  yield takeLatest('BRIEFCASE_STORE_GET_BRIEFCASE_LIST', briefcaseSaga.canBeCanceledGetBriefcaseList);
  yield takeLatest('BRIEFCASE_STORE_START_BRIEFCASE', briefcaseSaga.canBeCanceledStartBriefcase);
  yield takeLatest('BRIEFCASE_STORE_STOP_BRIEFCASE', briefcaseSaga.canBeCanceledStopBriefcase);
  yield takeLatest('BRIEFCASE_STORE_ADD_BRIEFCASE', briefcaseSaga.canBeCanceledAddBriefcase);
  yield takeLatest('BRIEFCASE_STORE_DELETE_BRIEFCASE', briefcaseSaga.canBeCanceledDeleteBriefcase);
  yield takeLatest('BRIEFCASE_STORE_UPDATE_BRIEFCASE', briefcaseSaga.canBeCanceledUpdateBriefcase);
  yield takeLatest('BRIEFCASE_STORE_UPDATE_BRIEFCASE_FILE', briefcaseSaga.canBeCanceledUpdateBriefcaseFile);
  yield takeLatest('BRIEFCASE_STORE_GET_BRIEFCASE', briefcaseSaga.canBeCanceledGetBriefcase);
  yield takeLatest('BRIEFCASE_STORE_GET_BRIEFCASE_CALLS', briefcaseSaga.canBeCanceledGetBriefcaseCalls);
  yield takeLatest('SETTINGS_STORE_GET_ALL', settingsSaga.canBeCanceledGetAllSettings);
  yield takeLatest('SETTINGS_STORE_UPDATE_MAIN', settingsSaga.canBeCanceledUpdateMainSettings);
  yield takeLatest('SETTINGS_STORE_UPDATE_RECALL', settingsSaga.canBeCanceledUpdateRecallSettings);
}

export default rootSaga;
