import {
  call, put, fork, take, cancel,
} from 'redux-saga/effects';
import api from '../../../api/api';
import actions from '../../actions/actions';
import { setErrorToast } from '../common/globalSaga';

function* getError(error) {
  if (error.response && error.response.data.description === 'Неверный токен') {
    yield put(actions.clearToken());
  } else if (error.response && error.response.data.description) {
    yield setErrorToast(error.response.data.description);
  } else {
    yield setErrorToast('При зугрузке данных произошла ошибка. Пожалуйста обновите страницу');
  }
}

/* ***************************** getBriefcaseList ********************** */
function* getBriefcaseList() {
  yield put(actions.briefcaseListStoreSetSection({
    dataLoaded: false,
  }));
  try {
    const list = yield call(api.getBriefCaseList);
    yield put(actions.briefcaseListStoreSetSection({
      dataLoaded: true,
      list: list.data,
    }));
  } catch (e) {
    yield put(actions.briefcaseListStoreSetSection({
      dataLoaded: true,
      list: [],
    }));
    yield getError(e);
  }
}

export function* canBeCanceledGetBriefcaseList() {
  const bgGetBriefcaseList = yield fork(getBriefcaseList);
  yield take('BRIEFCASE_STORE_GET_BRIEFCASE_LIST_CANCEL');
  yield cancel(bgGetBriefcaseList);
}

/* ***************************** updateBriefcase ********************** */
function* updateBriefcase(action) {
  try {
    yield call(api.updateBriefCase, action.value);
  } catch (e) {
    yield getError(e);
  }
}

export function* canBeCanceledUpdateBriefcase(action) {
  const bgUpdateBriefcase = yield fork(updateBriefcase, action);
  yield take('BRIEFCASE_STORE_UPDATE_BRIEFCASE_CANCEL');
  yield cancel(bgUpdateBriefcase);
}

/* ***************************** startBriefcase ********************** */
function* startBriefcase(action) {
  try {
    yield call(api.startBriefCase, action.id);
    yield getBriefcaseList();
  } catch (e) {
    yield getError(e);
  }
}

export function* canBeCanceledStartBriefcase(action) {
  const bgStartBriefcase = yield fork(startBriefcase, action);
  yield take('BRIEFCASE_STORE_START_BRIEFCASE_CANCEL');
  yield cancel(bgStartBriefcase);
}

/* ***************************** stopBriefcase ********************** */
function* stopBriefcase(action) {
  try {
    yield call(api.stopBriefCase, action.id);
    yield getBriefcaseList();
  } catch (e) {
    yield getError(e);
  }
}

export function* canBeCanceledStopBriefcase(action) {
  const bgStopBriefcase = yield fork(stopBriefcase, action);
  yield take('BRIEFCASE_STORE_STOP_BRIEFCASE_CANCEL');
  yield cancel(bgStopBriefcase);
}

/* ***************************** addBriefcase ********************** */
function* addBriefcase(action) {
  try {
    yield call(api.addBriefCase, action.value);
    yield getBriefcaseList();
  } catch (e) {
    yield getError(e);
  }
}

export function* canBeCanceledAddBriefcase(action) {
  const bgAddBriefcase = yield fork(addBriefcase, action);
  yield take('BRIEFCASE_STORE_ADD_BRIEFCASE_CANCEL');
  yield cancel(bgAddBriefcase);
}

/* ***************************** deleteBriefcase ********************** */
function* deleteBriefcase(action) {
  try {
    yield call(api.deleteBriefCase, action.id);
    yield getBriefcaseList();
  } catch (e) {
    yield getError(e);
  }
}

export function* canBeCanceledDeleteBriefcase(action) {
  const bgDeleteBriefcase = yield fork(deleteBriefcase, action);
  yield take('BRIEFCASE_STORE_DELETE_BRIEFCASE_CANCEL');
  yield cancel(bgDeleteBriefcase);
}

/* ***************************** updateBriefcaseFile ********************** */
function* updateBriefcaseFile(action) {
  try {
    yield call(api.uploadBriefCaseFile, action.id, action.value);
  } catch (e) {
    yield getError(e);
  }
}

export function* canBeCanceledUpdateBriefcaseFile(action) {
  const bgUpdateBriefcaseFile = yield fork(updateBriefcaseFile, action);
  yield take('BRIEFCASE_STORE_UPDATE_BRIEFCASE_FILE_CANCEL');
  yield cancel(bgUpdateBriefcaseFile);
}

/* ***************************** getBriefcaseCalls ********************** */
function* getBriefcaseCalls(action) {
  yield put(actions.briefcaseItemStoreSetSection({
    tableDataLoaded: false,
  }));
  try {
    const items = yield call(api.getBriefCaseItemCalls, action.id);
    yield put(actions.briefcaseItemStoreSetSection({
      tableDataLoaded: true,
      items: items.data,
    }));
  } catch (e) {
    yield put(actions.briefcaseItemStoreSetSection({
      tableDataLoaded: true,
      items: [],
    }));
    yield getError(e);
  }
}

export function* canBeCanceledGetBriefcaseCalls(action) {
  const bgGetBriefcaseCalls = yield fork(getBriefcaseCalls, action);
  yield take('BRIEFCASE_STORE_GET_BRIEFCASE_CALLS_CANCEL');
  yield cancel(bgGetBriefcaseCalls);
}

/* ***************************** getBriefcase ********************** */
function* getBriefcase(action) {
  try {
    const item = yield call(api.getBriefCaseItem, action.id);
    yield getBriefcaseCalls(action);
    yield put(actions.briefcaseItemStoreSetSection({
      dataLoaded: true,
      ...item.data,
    }));
  } catch (e) {
    yield put(actions.briefcaseItemStoreSetSection({
      dataLoaded: true,
    }));
    yield getError(e);
  }
}

export function* canBeCanceledGetBriefcase(action) {
  const bgGetBriefcase = yield fork(getBriefcase, action);
  yield take('BRIEFCASE_STORE_GET_BRIEFCASE_CANCEL');
  yield cancel(bgGetBriefcase);
}
