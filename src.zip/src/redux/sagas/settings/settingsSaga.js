import {
  call, put, fork, take, cancel,
} from 'redux-saga/effects';
import api from '../../../api/api';
import actions from '../../actions/actions';
import { setErrorToast, setSuccessToast } from '../common/globalSaga';

function* getError(error) {
  if (error.response && error.response.data.description === 'Неверный токен') {
    yield put(actions.clearToken());
  } else if (error.response && error.response.data.description) {
    yield setErrorToast(error.response.data.description);
  } else {
    yield setErrorToast('При зугрузке данных произошла ошибка. Пожалуйста обновите страницу');
  }
}

/* ***************************** getAllSettings ********************** */
function* getAllSettings() {
  try {
    const main = yield call(api.getMainSettings);
    const recall = yield call(api.getRecallSettings);
    yield put(actions.settingsStoreSetSection({
      dataLoaded: true,
      main: main.data,
      recall: recall.data,
    }));
  } catch (e) {
    yield put(actions.settingsStoreSetSection({
      dataLoaded: true,
      main: {},
      recall: [],
    }));
    yield getError(e);
  }
}

export function* canBeCanceledGetAllSettings() {
  const bgGetAllSettings = yield fork(getAllSettings);
  yield take('SETTINGS_STORE_GET_ALL_CANCEL');
  yield cancel(bgGetAllSettings);
}

/* ***************************** updateMainSettings ********************** */
function* updateMainSettings(action) {
  yield put(actions.settingsStoreSetSection({
    updatingMainSettings: true,
  }));
  try {
    yield call(api.updateMainSettings, action.value);
    yield put(actions.settingsStoreSetSection({
      updatingMainSettings: false,
    }));
    yield setSuccessToast('Основные настройки успешно сохранены');
  } catch (e) {
    yield put(actions.settingsStoreSetSection({
      updatingMainSettings: false,
    }));
    yield getError(e);
  }
}

export function* canBeCanceledUpdateMainSettings(action) {
  const bgUpdateMainSettings = yield fork(updateMainSettings, action);
  yield take('SETTINGS_STORE_UPDATE_MAIN_CANCEL');
  yield cancel(bgUpdateMainSettings);
}

/* ***************************** updateRecallSettings ********************** */
function* updateRecallSettings(action) {
  yield put(actions.settingsStoreSetSection({
    updatingRecallSettings: true,
  }));
  try {
    yield call(api.updateRecallSettings, action.value);
    yield put(actions.settingsStoreSetSection({
      updatingRecallSettings: false,
    }));
    yield setSuccessToast('Настройки перезвона успешно сохранены');
  } catch (e) {
    yield put(actions.settingsStoreSetSection({
      updatingRecallSettings: false,
    }));
    yield getError(e);
  }
}

export function* canBeCanceledUpdateRecallSettings(action) {
  const bgUpdateRecallSettings = yield fork(updateRecallSettings, action);
  yield take('SETTINGS_STORE_UPDATE_RECALL_CANCEL');
  yield cancel(bgUpdateRecallSettings);
}
