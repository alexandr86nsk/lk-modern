/* ************************** briefcaseStore  ******************************** */
export const briefcaseListStoreSetSection = (value) => ({
  type: 'BRIEFCASE_LIST_STORE_SET_SECTION',
  value,
});

export const briefcaseListStoreClear = () => ({
  type: 'BRIEFCASE_LIST_STORE_CLEAR',
});

export const briefcaseItemStoreSetSection = (value) => ({
  type: 'BRIEFCASE_ITEM_STORE_SET_SECTION',
  value,
});

export const briefcaseItemStoreClear = () => ({
  type: 'BRIEFCASE_ITEM_STORE_CLEAR',
});

export const briefcaseStoreGetBriefcaseList = () => ({
  type: 'BRIEFCASE_STORE_GET_BRIEFCASE_LIST',
});

export const briefcaseStoreGetBriefcaseListCancel = () => ({
  type: 'BRIEFCASE_STORE_GET_BRIEFCASE_LIST_CANCEL',
});

export const briefcaseStoreStartBriefcase = (id) => ({
  type: 'BRIEFCASE_STORE_START_BRIEFCASE',
  id,
});

export const briefcaseStoreStartBriefcaseCancel = () => ({
  type: 'BRIEFCASE_STORE_START_BRIEFCASE_CANCEL',
});

export const briefcaseStoreStopBriefcase = (id) => ({
  type: 'BRIEFCASE_STORE_STOP_BRIEFCASE',
  id,
});

export const briefcaseStoreStopBriefcaseCancel = () => ({
  type: 'BRIEFCASE_STORE_STOP_BRIEFCASE_CANCEL',
});

export const briefcaseStoreAddBriefcase = (value) => ({
  type: 'BRIEFCASE_STORE_ADD_BRIEFCASE',
  value,
});

export const briefcaseStoreAddBriefcaseCancel = () => ({
  type: 'BRIEFCASE_STORE_ADD_BRIEFCASE_CANCEL',
});

export const briefcaseStoreDeleteBriefcase = (id) => ({
  type: 'BRIEFCASE_STORE_DELETE_BRIEFCASE',
  id,
});

export const briefcaseStoreDeleteBriefcaseCancel = () => ({
  type: 'BRIEFCASE_STORE_DELETE_BRIEFCASE_CANCEL',
});

export const briefcaseStoreUpdateBriefcase = (value) => ({
  type: 'BRIEFCASE_STORE_UPDATE_BRIEFCASE',
  value,
});

export const briefcaseStoreUpdateBriefcaseCancel = () => ({
  type: 'BRIEFCASE_STORE_UPDATE_BRIEFCASE_CANCEL',
});

export const briefcaseStoreUpdateBriefcaseFile = (id, value) => ({
  type: 'BRIEFCASE_STORE_UPDATE_BRIEFCASE_FILE',
  id,
  value,
});

export const briefcaseStoreUpdateBriefcaseFileCancel = () => ({
  type: 'BRIEFCASE_STORE_UPDATE_BRIEFCASE_FILE_CANCEL',
});

export const briefcaseStoreGetBriefcase = (id) => ({
  type: 'BRIEFCASE_STORE_GET_BRIEFCASE',
  id,
});

export const briefcaseStoreGetBriefcaseCancel = () => ({
  type: 'BRIEFCASE_STORE_GET_BRIEFCASE_CANCEL',
});

export const briefcaseStoreGetBriefcaseCalls = (id) => ({
  type: 'BRIEFCASE_STORE_GET_BRIEFCASE_CALLS',
  id,
});

export const briefcaseStoreGetBriefcaseCallsCancel = () => ({
  type: 'BRIEFCASE_STORE_GET_BRIEFCASE_CALLS_CANCEL',
});
