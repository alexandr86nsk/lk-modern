/* ******************************* SettingsStore  ********************************************** */
export const settingsStoreSetSection = (value) => ({
  type: 'SETTINGS_STORE_SET_SECTION',
  value,
});

export const settingsStoreSetSubSection = (name, value) => ({
  type: 'SETTINGS_STORE_SET_SUB_SECTION',
  name,
  value,
});

export const settingsStoreChangeRecallItem = (id, value) => ({
  type: 'SETTINGS_STORE_CHANGE_RECALL_ITEM',
  id,
  value,
});

export const settingsStoreClear = () => ({
  type: 'SETTINGS_STORE_CLEAR',
});

export const settingsStoreGetAll = () => ({
  type: 'SETTINGS_STORE_GET_ALL',
});

export const settingsStoreGetAllCancel = () => ({
  type: 'SETTINGS_STORE_GET_ALL_CANCEL',
});

export const settingsStoreGetMain = () => ({
  type: 'SETTINGS_STORE_GET_MAIN',
});

export const settingsStoreGetMainCancel = () => ({
  type: 'SETTINGS_STORE_GET_MAIN_CANCEL',
});

export const settingsStoreUpdateMain = (value) => ({
  type: 'SETTINGS_STORE_UPDATE_MAIN',
  value,
});

export const settingsStoreUpdateMainCancel = () => ({
  type: 'SETTINGS_STORE_UPDATE_MAIN_CANCEL',
});

export const settingsStoreUpdateRecall = (value) => ({
  type: 'SETTINGS_STORE_UPDATE_RECALL',
  value,
});

export const settingsStoreUpdateRecallCancel = () => ({
  type: 'SETTINGS_STORE_UPDATE_RECALL_CANCEL',
});
