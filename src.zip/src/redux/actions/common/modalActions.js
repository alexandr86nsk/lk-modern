/* ******************************* ModalStore  ********************************************** */
export const modalStoreSet = (value) => ({
  type: 'MODAL_STORE_SET',
  value,
});

export const modalStoreClear = () => ({
  type: 'MODAL_STORE_CLEAR',
});

export const modalStoreSetSection = (value) => ({
  type: 'MODAL_STORE_SET_SECTION',
  value,
});

export const modalStoreSetValue = (name, value) => ({
  type: 'MODAL_STORE_SET_VALUE',
  name,
  value,
});

export const modalStoreSetTempDataValue = (name, value) => ({
  type: 'MODAL_STORE_SET_TEMP_DATA_VALUE',
  name,
  value,
});
