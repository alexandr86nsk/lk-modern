import * as modal from './common/modalActions';
import * as toasts from './common/toastsActions';
import * as pageControlActions from './common/pageControlActions';
import * as token from './token/tokenActions';
import * as briefcase from './briefcase/briefcaseActions';
import * as settings from './settings/settingsActions';
import * as user from './user/userActions';
import * as global from './common/globalActions';

const actions = {
  ...modal,
  ...toasts,
  ...pageControlActions,
  ...token,
  ...briefcase,
  ...settings,
  ...user,
  ...global,
};

export default actions;
