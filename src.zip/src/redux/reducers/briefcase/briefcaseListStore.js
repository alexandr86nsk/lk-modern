const initialBriefcaseListStore = {
  dataLoaded: false,
};

export default function briefcaseListStore(state = initialBriefcaseListStore, action) {
  switch (action.type) {
    case 'BRIEFCASE_LIST_STORE_SET_SECTION':
      return {
        ...state,
        ...action.value,
      };
    case 'BRIEFCASE_LIST_STORE_CLEAR':
      return initialBriefcaseListStore;
    default:
      return state;
  }
}
