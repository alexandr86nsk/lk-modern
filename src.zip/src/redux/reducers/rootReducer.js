import { combineReducers } from 'redux';
import { connectRouter } from 'connected-react-router';
import authStore from './auth/authStore';
import userStore from './user/userStore';
import tokenStore from './token/tokenStore';
import modalStore from './common/modalStore';
import pageControlStore from './common/pageControlStore';
import toastsStore from './common/toastsStore';
import globalStore from './common/globalStore';
import settingsStore from './settings/settingsStore';
import briefcaseListStore from './briefcase/briefcaseListStore';
import briefcaseItemStore from './briefcase/briefcaseItemStore';

const rootReducer = (history) => combineReducers({
  router: connectRouter(history),
  settingsStore,
  authStore,
  pageControlStore,
  userStore,
  tokenStore,
  globalStore,
  modalStore,
  toastsStore,
  briefcaseListStore,
  briefcaseItemStore,
});

export default rootReducer;
