const initialSettingsStore = {
  dataLoaded: false,
};

export default function settingsStore(state = initialSettingsStore, action) {
  switch (action.type) {
    case 'SETTINGS_STORE_SET_SECTION':
      return {
        ...state,
        ...action.value,
      };
    case 'SETTINGS_STORE_SET_SUB_SECTION':
      return {
        ...state,
        [action.name]: {
          ...state[action.name],
          ...action.value,
        },
      };
    case 'SETTINGS_STORE_CHANGE_RECALL_ITEM':
      return {
        ...state,
        recall: state.recall.map((v) => {
          if (v.EventCode === action.id) {
            return {
              ...v,
              ...action.value,
            };
          }
          return v;
        }),
      };
    case 'SETTINGS_STORE_CLEAR':
      return initialSettingsStore;
    default:
      return state;
  }
}
