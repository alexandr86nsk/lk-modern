import React from 'react';
import './UISelect.scss';
import { Scrollbars } from 'react-custom-scrollbars';
import useOutsideClick from '../UICustomHooks/useOutsideClick/useOutsideClick';
import UISelectOption from './UISelectOption';
import ArrowIcon from './UISelect-button-icon.svg';


function UISelect(props) {
  const {
    options = [],
    selected = '',
    maxHeight = 'max-content',
    callback,
  } = props || {};

  const selectEl = React.useRef(null);
  const [showOptions, setShowOptions] = React.useState(false);

  const handleHide = React.useCallback(() => {
    setShowOptions(false);
  }, []);

  useOutsideClick(selectEl, handleHide);

  React.useEffect(() => {
    if (showOptions) {
      document.body.classList.add('select');
    } else {
      document.body.classList.remove('select');
    }
  }, [showOptions]);

  const selectOption = React.useCallback(
    (item) => {
      setShowOptions(false);
      callback(item);
    }, [callback],
  );

  const handleChangeOptionsView = React.useCallback(() => {
    setShowOptions(!showOptions);
  }, [showOptions]);

  const memoizedOptions = React.useMemo(() => (
    options.map((v) => (
      <UISelectOption key={v} option={v} callback={selectOption} />
    ))), [options, selectOption]);

  return (
    <div
      className={`ui-select-block ${showOptions ? 'active' : ''}`}
      ref={selectEl}
    >
      <input
        className="ui-select-block__input"
        placeholder={selected}
        onClick={handleChangeOptionsView}
        readOnly
      />
      <button
        type="button"
        aria-label="show-options"
        className="ui-select-block__button"
        onClick={handleChangeOptionsView}
      >
        <ArrowIcon />
      </button>
      <div className="ui-select-block__options-wrapper">
        <div
          role="presentation"
          className="ui-select-block__options-background"
          onClick={handleChangeOptionsView}
        />
        <div className="ui-select-block__options">
          <Scrollbars
            universal
            autoHeight
            autoHeightMin={0}
            autoHeightMax={maxHeight}
          >
            <ul>
              {memoizedOptions}
            </ul>
          </Scrollbars>
        </div>
      </div>
    </div>
  );
}

export default React.memo(UISelect);
