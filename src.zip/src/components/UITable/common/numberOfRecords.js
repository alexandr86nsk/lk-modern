const numberOfRecords = [
  '5',
  '10',
  '20',
  '50',
];

export default numberOfRecords;
