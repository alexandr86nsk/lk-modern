import React from 'react';


function UITableFilter(props) {
  const {
    filterBody,
    filterClear,
  } = props;

  const handleClear = React.useCallback(() => {
    if (filterClear) {
      filterClear();
    }
  }, [filterClear]);

  return (
    <div className="ui-table__filter active absolute">
      <div className="filter__body">
        {filterBody}
        <div className="filter__clear-block">
          <div role="presentation" className="filter__clear-btn" onClick={handleClear}>
            Очистить
          </div>
        </div>
      </div>
    </div>
  );
}

export default React.memo(UITableFilter);
