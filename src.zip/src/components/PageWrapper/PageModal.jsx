import React from 'react';
import { connect } from 'react-redux';
import actions from '../../redux/actions/actions';
import UIModal from '../UIModal/UIModal';

function PageModal(props) {
  const {
    show,
    data,
    tempData,
    callback,
    outputBody,
    modalStoreClear,
    requiredFields = [],
  } = props;

  const handleCloseModal = React.useCallback((value) => {
    if (value) {
      callback(data, tempData);
    }
    modalStoreClear();
  }, [callback, data, modalStoreClear, tempData]);

  const memoizedValidationForm = React.useMemo(() => {
    let errors = 0;
    requiredFields.forEach((v) => {
      if (v.type === 'length') {
        if (tempData[v.name].length < v.validation) {
          errors += 1;
        }
      }
      if (v.type === 'required') {
        if (!tempData[v.name]) {
          errors += 1;
        }
      }
    });
    return !!errors;
  }, [requiredFields, tempData]);

  return (
    <div className="page-modal">
      {show
      && (
      <UIModal
        {...outputBody}
        callback={handleCloseModal}
        disabledPositive={memoizedValidationForm}
      />
      )}
    </div>
  );
}

const mapStateToProps = (state) => ({
  show: state.modalStore.show,
  outputBody: state.modalStore.outputBody,
  data: state.modalStore.data,
  tempData: state.modalStore.tempData,
  callback: state.modalStore.callback,
  requiredFields: state.modalStore.requiredFields,
});

const mapDispatchToProps = { ...actions };

export default connect(mapStateToProps, mapDispatchToProps)(React.memo(PageModal));
