import React from 'react';
import { Scrollbars } from 'react-custom-scrollbars';
import { connect } from 'react-redux';
import * as actions from '../../redux/actions/actions';
import UIToasts from '../UIToasts/UIToasts';
import UISideBar from '../UISidebar/UISidebar';
import PageHeader from '../../containers/PageHeader/PageHeader';
import PageFooter from '../../containers/PageFooter/PageFooter';
import PageModal from './PageModal';
import PageControl from './PageControl';
import useScrollPage from '../UICustomHooks/useScrollPage/useScrollPage';
import UIScrollToTop from '../UIScrollToTop/UIScrollToTop';


function PageWrapper(props) {
  const {
    children,
    isAuth = false,
  } = props;

  const pageEl = React.useRef(null);
  const [scroll, setScroll] = React.useState(false);
  useScrollPage(setScroll, pageEl);

  return (
    <>
      {isAuth
        ? (
          <>
            <UIToasts />
            <div className="menu-container">
              <UISideBar />
            </div>
            <div className="page-container">
              <PageHeader />
              <div className="page">
                <Scrollbars
                  style={{ height: '100%' }}
                  autoHeight
                  autoHeightMin="100%"
                  autoHeightMax="100%"
                  renderTrackVertical={(prop) => <div {...prop} className="custom-scrollbar__track-vertical" />}
                  renderThumbVertical={(prop) => <div {...prop} className="custom-scrollbar__thumb-vertical" />}
                  renderTrackHorizontal={(prop) => <div {...prop} className="custom-scrollbar__track-horizontal" />}
                  renderThumbHorizontal={(prop) => <div {...prop} className="custom-scrollbar__thumb-horizontal" />}
                  renderView={({ style, ...prop }) => (
                    <div
                      {...prop}
                      className="custom-scrollbar__view"
                      style={{ ...style, overflowX: 'hidden' }}
                    />
                  )}
                >
                  <div className="page__scrollable-block" ref={pageEl}>
                    {children}
                  </div>
                </Scrollbars>
              </div>
              <PageFooter />
              <PageModal />
              <PageControl />
              <UIScrollToTop isVisible={scroll} refEl={pageEl.current} />
            </div>
          </>
        )
        : (
          <>
            {children}
          </>
        )}

    </>
  );
}

const mapDispatchToProps = { ...actions };

export default connect(null, mapDispatchToProps)(React.memo(PageWrapper));
