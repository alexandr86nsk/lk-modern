import React, { useState, useRef } from 'react';
import './UISearch.scss';
import SearchIcon from '../../static/images/search.svg';
import UILoader from '../UILoader/UILoader';


function UISearch(props) {
  const {
    placeholder = 'Поиск',
    results = [],
    hideResults,
    callback,
  } = props;

  const resultsEl = useRef(null);
  const [searchString, setSearchString] = useState('');
  const [loading, setLoading] = React.useState(false);

  const handleChangeInput = React.useCallback((event) => {
    if (callback) {
      setLoading(true);
      setSearchString(event.target.value);
      callback(event.target.value);
      setTimeout(() => setLoading(false), 300);
    }
  }, [callback]);

  const memoizedResults = React.useMemo(() => {
    if (results.length) {
      return results.map((v) => (
        <li key={v.id}>{v}</li>
      ));
    }
    return (
      <li>Поиск не дал результатов</li>
    );
  }, [results]);

  return (
    <div className={`ui-search ${searchString ? 'active' : ''}`}>
      <input
        className="ui-search__input"
        placeholder={placeholder}
        value={searchString}
        onChange={handleChangeInput}
      />
      {searchString && !loading && !hideResults && (
        <ul className="ui-search__results" ref={resultsEl}>
          {memoizedResults}
        </ul>
      )}
      <div className="ui-search__icon">
        {loading ? <UILoader size="small" /> : <SearchIcon />}
      </div>
    </div>
  );
}

export default React.memo(UISearch);
