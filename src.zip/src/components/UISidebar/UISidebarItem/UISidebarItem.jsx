import React from 'react';
import UISidebarItemLinkBtn from './UISidebarItemLinkBtn';
import UISidebarItemBtn from './UISidebarItemBtn';


function UISidebarItem(props) {
  const {
    item,
    active = false,
    open = false,
    subItems = [],
  } = props;

  const {
    title,
    link,
    icon,
  } = item;

  const [showSubMenu, setShowSubMenu] = React.useState(open);
  React.useEffect(() => setShowSubMenu(open), [open]);

  const handleShowSubMenu = React.useCallback(
    () => setShowSubMenu(!showSubMenu), [showSubMenu],
  );

  return (
    <li className={`ui-sidebar__item ${active && 'active'} ${showSubMenu && 'open'}`}>
      {link
        ? (
          <UISidebarItemLinkBtn
            title={title}
            link={link}
            icon={icon}
          />
        )
        : (
          <>
            <UISidebarItemBtn
              title={title}
              icon={icon}
              callback={handleShowSubMenu}
            />
            <div className="ui-sidebar__sub-items-list">
              {
                subItems.map((v) => (
                  <UISidebarItemLinkBtn
                    key={v.id}
                    title={v.title}
                    link={v.link}
                    icon={v.icon}
                    active={v.active}
                  />
                ))
              }
            </div>
          </>
        )}
    </li>
  );
}

export default React.memo(UISidebarItem);
