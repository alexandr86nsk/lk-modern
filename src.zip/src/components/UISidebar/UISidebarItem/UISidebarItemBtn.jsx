import React from 'react';
import LeftArrow from '../../../static/images/arrow_left.svg';


function UISidebarItemBtn(props) {
  const {
    title,
    icon,
    callback,
  } = props;

  return (
    <div
      role="presentation"
      className="ui-sidebar__btn"
      onClick={callback}
    >
      <div>
        {icon && icon}
      </div>
      <div>
        <span>{title}</span>
        <LeftArrow className="ui-sidebar__arrow" />
      </div>
    </div>
  );
}

export default React.memo(UISidebarItemBtn);
