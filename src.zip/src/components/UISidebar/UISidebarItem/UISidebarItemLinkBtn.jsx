import React from 'react';
import { Link } from 'react-router-dom';


function UISidebarItemLinkBtn(props) {
  const {
    title,
    link,
    icon,
    active,
  } = props;

  return (
    <Link to={link} className={`ui-sidebar__link-btn ${active && 'active'}`}>
      <div>
        {icon && icon}
      </div>
      <div>
        <span>{title}</span>
      </div>
    </Link>
  );
}

export default React.memo(UISidebarItemLinkBtn);
