import React from 'react';
import BriefIcon from '../../static/images/work-24px.svg';
import SettingsIcon from '../../static/images/settings.svg';


const UISidebarList = [
  {
    id: 0,
    title: 'Кампании',
    link: '/briefcase',
    icon: <BriefIcon />,
    items: [],
  },
  {
    id: 1,
    title: 'Настройки',
    link: '/settings',
    icon: <SettingsIcon />,
    items: [],
  },
];

export default UISidebarList;
