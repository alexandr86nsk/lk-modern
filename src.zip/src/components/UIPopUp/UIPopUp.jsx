import React from 'react';
import './UIPopUp.scss';
import { Scrollbars } from 'react-custom-scrollbars';
import CloseIcon from '../../static/images/close-10px.svg';
import useScrollPage from '../UICustomHooks/useScrollPage/useScrollPage';
import UIScrollToTop from '../UIScrollToTop/UIScrollToTop';

function UIPopUp(props) {
  const {
    callback,
    component,
  } = props;

  const [scroll, setScroll] = React.useState(false);
  const pageEl = React.useRef(null);
  useScrollPage(setScroll, pageEl);

  const [state, setState] = React.useState('entering');

  const handleClose = React.useCallback(() => {
    setState('exiting');
    if (callback) {
      setTimeout(() => callback(), 500);
    }
  }, [callback]);

  React.useEffect(() => {
    function handleClickEscape(event) {
      if (event.key === 'Escape') {
        handleClose();
      }
    }
    document.addEventListener('keydown', handleClickEscape);
    return () => {
      document.removeEventListener('keydown', handleClickEscape);
    };
  }, [handleClose]);

  React.useEffect(() => {
    setTimeout(() => setState('entered'), 0);
  }, []);

  return (
    <div className={`ui-popup ${state}`}>
      <div className="ui-popup__wrapper">
        <div className="ui-popup__top-panel">
          <div
            role="presentation"
            className="ui-popup__close-block"
            onClick={handleClose}
          >
            <CloseIcon />
          </div>
        </div>
        <div className="ui-popup__data-block">
          <Scrollbars
            style={{ height: '100%' }}
            autoHeight
            autoHeightMin="100%"
            autoHeightMax="100%"
            renderTrackVertical={(prop) => <div {...prop} className="custom-scrollbar__track-vertical" />}
            renderThumbVertical={(prop) => <div {...prop} className="custom-scrollbar__thumb-vertical" />}
            renderView={({ style, ...prop }) => (
              <div
                {...prop}
                className="custom-scrollbar__view"
                style={{ ...style }}
              />
            )}
          >
            <div className="ui-popup__body" ref={pageEl}>
              {component && component}
            </div>
          </Scrollbars>
          <UIScrollToTop isVisible={scroll} refEl={pageEl.current} />
        </div>
      </div>
    </div>
  );
}

export default React.memo(UIPopUp);
