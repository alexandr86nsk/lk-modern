import React from 'react';
import './UIInput.scss';
import InputMask from 'react-input-mask';
import * as moment from 'moment';
import NumberFormat from 'react-number-format';
import { validateEmail, validateUrl } from '../utilities/helpers';
import ErrorIcon from '../../static/images/error-24px.svg';
import SuccessIcon from '../../static/images/check_circle-24px.svg';


function UIInput(props) {
  const {
    title,
    name = '',
    callback,
    mask = '',
    minLength = 0,
    data,
    email,
    url,
    disabled,
    dateTime,
    dateFormat = 'LLL',
    password,
    successFormat,
    numberFormat,
    required,
    hint,
  } = props;

  const handleChangeMaskInput = React.useCallback((event) => {
    if (callback) {
      callback(name, event.target.value);
    }
  }, [callback, name]);

  const handleChangeNumberInput = React.useCallback((values) => {
    if (callback) {
      const { value } = values;
      callback(name, value);
    }
  }, [callback, name]);

  const composeLength = React.useCallback(() => data.length >= minLength, [data, minLength]);

  const className = React.useMemo(() => {
    let str = 'ui-input';
    if (required) {
      str = `${str} required`;
      if (!data) {
        str = `${str} error`;
      }
    }
    if (data) {
      if (minLength) {
        if (composeLength()) {
          str = `${str} success`;
        } else {
          str = `${str} error`;
        }
      }
      if (email) {
        if (validateEmail(data)) {
          str = `${str} success`;
        } else {
          str = `${str} error`;
        }
      }
      if (url) {
        if (validateUrl(data)) {
          str = `${str} success`;
        } else {
          str = `${str} error`;
        }
      }
    }
    return str;
  }, [composeLength, data, email, minLength, required, url]);

  const momentDate = React.useMemo(() => {
    if (dateTime && data) {
      moment.locale('ru');
      return moment(data).format(dateFormat);
    }
    return data || '';
  }, [data, dateFormat, dateTime]);

  return (
    <div className={className}>
      {title
      && (
        <div className="ui-input__title font-type-b-10">
          <span className="ellipsis-element">{title}</span>
          {required && <div className="required-icon">*</div>}
          {hint && hint}
        </div>
      )}
      <div className="ui-input__body">
        {!numberFormat ? (
          <InputMask
            className="ui-input__input"
            onChange={handleChangeMaskInput}
            alwaysShowMask
            mask={mask}
            value={momentDate}
            maskChar={null}
            formatChars={{
              0: '[0-9]',
              a: '[A-Za-z]',
              '*': '[A-Za-z0-9]',
            }}
            type={password
              ? 'password'
              : 'text'}
            disabled={disabled}
          />
        )
          : (
            <NumberFormat
              className="ui-input__input"
              thousandSeparator
              onValueChange={handleChangeNumberInput}
              value={data || ''}
            />
          )}
        <div className="ui-input__error" title="Ошибка">
          <ErrorIcon />
        </div>
        <div className="ui-input__success" title="Верно">
          <SuccessIcon />
        </div>
        {successFormat && <div className="ui-input__i-error">{successFormat}</div>}
      </div>
    </div>
  );
}

export default React.memo(UIInput);
