import React from 'react';
import './UIReactSelect.scss';
import Select from 'react-select';
import ErrorIcon from '../../static/images/error-24px.svg';
import SuccessIcon from '../../static/images/check_circle-24px.svg';


function UIReactSelect(props) {
  const {
    title,
    options = [],
    defaultOptions = [],
    name,
    data = '',
    callback,
    noOptionsMessage = 'Данные не загружены',
    hint,
    required,
    isClearable = true,
    isMulti,
    placeholder = 'Выберите значение',
  } = props;

  const handleChange = React.useCallback((value) => {
    if (callback) {
      if (isMulti) {
        setTimeout(
          () => callback(name, value && value.length ? value.map((v) => v.value) : null),
          value && value.length ? 0 : 200,
        );
      } else {
        callback(name, value ? value.value : null);
      }
    }
  }, [callback, isMulti, name]);

  const className = React.useMemo(() => {
    let str = 'ui-react-select';
    if (required) {
      str = `${str} required`;
      if (!data) {
        str = `${str} error`;
      } else {
        str = `${str} success`;
      }
    }
    return str;
  }, [data, required]);

  const checkDefaultOptions = React.useCallback(() => {
    if (defaultOptions[0]) {
      return defaultOptions;
    }
    return options;
  }, [defaultOptions, options]);

  return (
    <div className={className}>
      {title
      && (
        <div className="ui-react-select__title font-type-b-10" title={title}>
          <span className="ellipsis-element">{title}</span>
          {required && <div className="required-icon">*</div>}
          {hint && hint}
        </div>
      )}
      <div className="ui-react-select__body">
        <Select
          className="ui-react-select__container"
          classNamePrefix="ui-react-select"
          placeholder={placeholder}
          noOptionsMessage={() => noOptionsMessage}
          options={options}
          onChange={handleChange}
          value={
            !isMulti
              ? (checkDefaultOptions().filter((v) => v.value === data)[0] || '')
              // eslint-disable-next-line max-len
              : (Array.isArray(data) ? (data.map((x) => checkDefaultOptions().filter((v) => v.value === x)[0])) : '')
          }
          menuPlacement="auto"
          isClearable={isClearable}
          isMulti={isMulti}
          closeMenuOnSelect={!isMulti}
        />
        <div className="ui-react-select__error" title="Ошибка">
          <ErrorIcon />
        </div>
        <div className="ui-react-select__success" title="Верно">
          <SuccessIcon />
        </div>
      </div>
    </div>
  );
}

export default React.memo(UIReactSelect);
